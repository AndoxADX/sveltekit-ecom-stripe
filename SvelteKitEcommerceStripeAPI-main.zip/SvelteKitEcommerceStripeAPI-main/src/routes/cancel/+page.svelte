
<!-- localhost:5173/cancel -->

<div class="container h-full mx-auto flex justify-center items-center">
	<div class="grid grid-cols-3 gap-4">
		<div class="col-span-3">
			<h1>Sorry to see you canceled your payment</h1>
		</div>
	</div>
</div>
