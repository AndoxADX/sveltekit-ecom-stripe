
<!-- localhost:5173/success -->

<div class="container h-full mx-auto flex justify-center items-center">
	<div class="grid grid-cols-3 gap-4">
		<div class="col-span-3">
			<h1>Successful payment! Thanks for shopping with us.</h1>
		</div>
	</div>
</div>
